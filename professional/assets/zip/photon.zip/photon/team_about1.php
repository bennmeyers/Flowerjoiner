<?php include("includes/global/header.php"); ?>
<div id="page_team_butrick" class="page_team">
<?php include("includes/content/header.php"); ?>
	<script>
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'team'; //set the blurb image path
			$_GET['p'] = 'header_team_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
			<img src="images/BB.png" alt="" width="150" height="103" border="3">
			<p><strong>Brandon Butrick</strong> &#150; Producer/director, owner<br>
			<a href="mailto:brandon@photoncreative.com">brandon@photoncreative.com</a></p>
			<p>Since starting the company in 2001, Brandon has been editor, animator, director and producer, while growing Photon from a one-man editorial and design boutique to a full-fledged production company. He plays a hands-on role in all of Photon's projects, and is known as an exceptional creative collaborator, both on set and in the editing studio.</p>
			<p>Brandon discovered in college that, nestled among his passions for science, technology, literature, and art lay a miraculous world known as media - video, photography, music, animation, interactivity - and found the storytelling opportunities afforded by this collective set of creative disciplines irresistible.</p>
			<p>He started his career at Pyramid Pictures, working with director Gregg Shelby for over 7 years on 35mm TV spots for Sears, Oscar Meyer, Yamaha, Time Life Books, and many other accounts through Pyramid's Milwaukee, Chicago, and Los Angles offices. Moving to San Francisco in 1994, he built a strong following as a freelance editor, and eventually landed at Total Media Group, where he worked as a senior staff editor until the end of 1999.</p>
			<p>In 1999 he co-founded a web media firm and at the height of the Web 1.0 era, they had assembled an incredible team of 16 designers and programmers and developed database-driven websites, flash animations, online learning tools, and web-videos. In 2001, following the dotcom crash, the team disbanded and Brandon founded Photon.</p>
			<p>Brandon lives in San Francisco with his family, and in his spare time, coaches youth sports and plays upright bass while his two sons begin to tackle his guitar collection.</p>
			<p><a href="team.php">back to team</a></p>
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>