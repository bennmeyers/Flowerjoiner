<?php include("includes/global/header.php"); ?>
<div id="page_map">
<?php include("includes/content/header.php"); ?>
	<script>
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['p'] = 'header_contact_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
		    <strong>Photon</strong><br />
		    1136 Clement St.<br />
		    San Francisco, CA, 94118<br />
		    Office 415-751-0499<br />
		    Fax 415-751-0499<br />
		    <a href="mailto:info@photoncreative.com">info@photoncreative.com</a><br />
		    <iframe width="740" height="443" style="margin:5px 0" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps?q=1136+clement+st&amp;ie=UTF8&amp;oe=utf-8&amp;client=firefox-a&amp;s=AARTsJrHGhSHYdP3YvXg3YEdzSmvC-OMgQ&amp;ll=37.793168,-122.467003&amp;spn=0.026452,0.04549&amp;z=14&amp;iwloc=addr&amp;output=embed" style="margin:0 0 10px;"></iframe>
		      <a href="http://maps.google.com/maps?q=1136+clement+st&amp;ie=UTF8&amp;oe=utf-8&amp;client=firefox-a&amp;ll=37.793168,-122.467003&amp;spn=0.026452,0.04549&amp;z=14&amp;iwloc=addr&amp;source=embed" style="color:#23001e;" target="_blank">View Larger Map</a>
		    
		
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>