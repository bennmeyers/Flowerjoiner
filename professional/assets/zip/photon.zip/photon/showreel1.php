<html>
<head>
<script src="jscript/jquery.min.js?v=0" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
	jQuery.get("xml/showreel.xml",{},function(xml) {
		$('track',xml).each(function(count) {
			var lsTitle = $(this).find("title").text();
			var lsLocation = $(this).find("location").text();
			$('.show_reel').append('<a href="demo09.php?movie=' + lsLocation + '" rel="prettyPopin">' + lsTitle + '</a>');
		}); // each
	}); // jQuery Get
}); // document
</script>
</head>
<body>
	<div class="show_reel">
	
	</div><!-- .show_reel -->
</body>
</html>