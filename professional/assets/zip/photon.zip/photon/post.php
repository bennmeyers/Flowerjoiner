<?php include("includes/global/header.php"); ?>
<script type="text/javascript">
var psXMLFile = "post.xml";
</script>
<div id="page_post">
<?php include("includes/content/header.php"); ?>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'post'; //set the blurb image path
			$_GET['p'] = 'navigation_post_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>