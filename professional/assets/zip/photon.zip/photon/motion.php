<?php include("includes/global/header.php"); ?>
<script type="text/javascript">
var psXMLFile = "motion.xml";
</script>
<div id="page_motion">
<?php include("includes/content/header.php"); ?>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'motion'; //set the blurb image path
			$_GET['p'] = 'navigation_motion_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>