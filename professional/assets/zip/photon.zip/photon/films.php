<?php include("includes/global/header.php"); ?>
<script type="text/javascript">
var psXMLFile = "films.xml";
</script>
<div id="page_films">
<?php include("includes/content/header.php"); ?>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'films'; //set the blurb image path
			$_GET['p'] = 'navigation_films_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>