<?php include("includes/global/header.php"); ?>
<div id="page_quote">
<?php include("includes/content/header.php"); ?>
	<script type="text/javascript">
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'quote'; //set the blurb image path
			$_GET['p'] = 'navigation_quote_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
			<?php
			        if(isset($_POST['submit']))
			        {
			        	$to = "info@photoncreative.com";
			            $subject = "Quote Request";
			            $email = $_POST['frm_email'];
			            $telephone = $_POST['frm_tele'];
			            $name = $_POST['frm_full_name'];
			            $company = $_POST['frm_company'];
			            $date = $_POST['frm_date'];
			            $type = $_POST['frm_type'];
			            $message = $_POST['frm_message'];
						$script = $_POST['frm_script'];
						$location = $_POST['frm_location'];
						$casting = $_POST['frm_casting'];
						$prodplan = $_POST['frm_prodplan'];
						$producer = $_POST['frm_producer'];
						$director = $_POST['frm_director'];
						$cinematographer = $_POST['frm_cinematographer'];
						$lighting = $_POST['frm_lighting'];
						$sound = $_POST['frm_sound'];
						$editing = $_POST['frm_editing'];
						$motion = $_POST['frm_motion'];
						$dvd = $_POST['frm_dvd'];
						$voice = $_POST['frm_voice'];
						$custom = $_POST['frm_custom'];
						$library = $_POST['frm_library'];
						$soundDes = $_POST['frm_soundDes'];
						$hd = $_POST['frm_hd'];
						$dof = $_POST['frm_dofadaptors'];
						$audio = $_POST['frm_audio'];
						$jibs = $_POST['frm_jibs'];
			            $headers = 'From: ' . $name_field . ' <' . $email_field . '>' . "\r\n";
			            $headers .= "Content-Type: text/html; charset=ISO-8859-1 ";
			            $headers .= "MIME-Version: 1.0 "; 
			            $body = "$message<br /><br /> <b>From:</b> $name<br /> <b>E-Mail:</b> $email<br />";

			                if ($telephone)
			                {
			                    $body .= "<b>Telephone:</b> $telephone<br />";
			                }

			                if ($name)
			                {
			                    $body .= "<b>Name:</b> $name<br />";
			                }

			                if ($company)
			                {
			                    $body .= "<b>Company:</b> $company<br />";
			                }

			                if ($date)
			                {
			                    $body .= "<b>Estimated production date:</b> $date<br />";
			                }

			                if ($type)
			                {
			                    $body .= "<b>Type of production:</b> $type<br />";
			                }

			                if ($message)
			                {
			                    $body .= "<b>Project description:</b> $message<br />";
			                }

							if ($script || $location || $casting || $prodplan)
							{
								$body .= "pre-production needs: ";
								if ($script)
								{
									$body .= "script: $script ";
								}
								if ($location)
								{
									$body .= "location: $location ";
								}
								if ($casting)
								{
									$body .= "casting: $casting ";
								}
								if ($prodplan)
								{
									$body .= "pre-production planning: $prodplan ";
								}
								$body .= "<br>";
							}

							if ($producer || $director || $cinematographer || $lighting || $sound)
							{
								$body .= "production needs: ";
								if ($producer)
								{
									$body .= "producer: $producer ";
								}
								if ($director)
								{
									$body .= "director: $director ";
								}
								if ($cinematographer)
								{
									$body .= "cinematographer: $cinematographer ";
								}
								if ($lighting)
								{
									$body .= "lighting: $lighting ";
								}
								if ($sound)
								{
									$body .= "sound: $sound ";
								}
								$body .= "<br>";
							}

							if ($editing || $motion || $dvd || $voice || $custom || $libary || $soundDes)
							{
								$body .= "post-production needs: ";
								if ($editing)
								{
									$body .= "editing: $editing ";
								}
								if ($motion)
								{
									$body .= "motion: $motion ";
								}
								if ($dvd)
								{
									$body .= "dvd authoring: $dvd ";
								}
								if ($voice)
								{
									$body .= "voice-over: $voice ";
								}
								if ($custom)
								{
									$body .= "custom music: $custom ";
								}
								if ($libary)
								{
									$body .= "library music: $libary ";
								}
								if ($soundDes)
								{
									$body .= "sound design: $soundDes ";
								}
								$body .= "<br>";
							}

							if ($hd || $dof || $audio || $jibs)
							{
								$body .= "editing needs: ";
								if ($hd)
								{
									$body .= "hd cameras: $hd ";
								}
								if ($dof)
								{
									$body .= "depth-of-field adaptors: $dof ";
								}
								if ($audio)
								{
									$body .= "audio equipment: $audio ";
								}
								if ($jibs)
								{
									$body .= "jibs/dollys/etc. $jibs ";
								}
								$body .= "<br>";
							}

			                if ($email)
			                {
			                    mail($to, $subject, $body, $headers);
			                    echo "<h1>thank you, $name.</h1>";
			                    echo "<p>your request for a Quote has been sent and Photon will get back to you shortly.</p>";
			                    echo "<p>*all information submitted is completely private</p>";
			                }
			                elseif ($email == "")
			                {
			                    echo "<h4>please enter an email address</h4>";
			                }
			        }
			        else
			        {
			    ?>
			        <form method="post" action="quote.html">
				        <p><strong>We would be happy to provide an estimate for your project!</strong></p>
						<p>Please provide us as much the following information as you can. We may need to contact you for additional details to get an accurate estimate.</p>
						<fieldset class="contact" style="border:0;">
			            	<div id="frm_email_div">
								<label class="label" for="frm_email">Email address:</label>
								<input type="text" name="frm_email" id="frm_email" class="text" />
								<span id="error_EmailAsterix" class="asterix">*</span>
								<span id="error_Email" class="error hidden">Please enter your email address</span>
							</div>
			            	<div id="frm_tele_div">
								<label class="label" for="frm_tele">Telephone #:</label>
								<input type="text" name="frm_tele" id="frm_tele" class="text" />
							</div>
			            	<div id="frm_full_name_div">
								<label class="label" for="frm_full_name">Name:</label>
								<input type="text" name="frm_full_name" id="frm_full_name" class="text" />
							</div>
			            	<div id="frm_company_div">
								<label class="label" for="frm_company">Company:</label>
								<input type="text" name="frm_company" id="frm_company" class="text" />
							</div>
			            	<div id="frm_date_div">
								<label class="label" for="frm_date">Estimated production date:</label>
								<input type="text" name="frm_date" id="frm_date" class="text" />
							</div>
			            	<div id="frm_type_div">
								<label class="label" for="frm_type">Type of production:</label>
								<input type="text" name="frm_type" id="frm_type" class="text" />
							</div>
			            	<div id="frm_message_div">
								<label class="label" for="frm_message">Describe the project:</label>
								<textarea name="frm_message" id="frm_message" rows="10" cols="20"></textarea>
							</div>
							<div><b>Services you need from Photon:</b></div>
							<div class="h_list" id="preprod_div">
								<div class="label">Pre-production: (check all that apply)</div>
								<div class="options"><span>
									<input type="checkbox" name="frm_script" id="frm_script" class="checkbox" />
									<label for="frm_script">Scriptwriting</label>
								</span>
								<span>
									<input type="checkbox" name="frm_location" id="frm_location" class="checkbox" />
									<label for="frm_location">Location</label>
								</span>
								<span>
									<input type="checkbox" name="frm_casting" id="frm_casting" class="checkbox" />
									<label for="frm_casting">Casting</label>
								</span>
								<span>
									<input type="checkbox" name="frm_prodplan" id="frm_prodplan" class="checkbox" />
									<label for="frm_prodplan">Production planning</label>
								</span>
								</div>
							</div>
							<div class="h_list" id="prod_div">
								<div class="label">Production: (check all that apply)</div>
								<div class="options">
									<span>
										<input type="checkbox" name="frm_producer" id="frm_producer" class="checkbox" />
										<label for="frm_producer">Producer</label>
									</span>
									<span>
										<input type="checkbox" name="frm_director" id="frm_director" class="checkbox" />
										<label for="frm_director">Director</label>
									</span>
									<span>
										<input type="checkbox" name="frm_cinematographer" id="frm_cinematographer" class="checkbox" />
										<label for="frm_cinematographer">Cinematographer</label>
									</span>
									<span>
										<input type="checkbox" name="frm_lighting" id="frm_lighting" class="checkbox" />
										<label for="frm_lighting">Lighting</label>
									</span>
									<span>
										<input type="checkbox" name="frm_sound" id="frm_sound" class="checkbox" />
										<label for="frm_sound">Sound</label>
									</span>
								</div>
							</div>
							<div class="h_list" id="postprod_div">
								<div class="label">Post-production: (check all that apply)</div>
								<div class="options">
								<span>
									<input type="checkbox" name="frm_editing" id="frm_editing" class="checkbox" />
									<label for="frm_editing">Editing</label>
								</span>
								<span>
									<input type="checkbox" name="frm_motion" id="frm_motion" class="checkbox" />
									<label for="frm_motion">Motion graphics</label>
								</span>
								<span>
									<input type="checkbox" name="frm_dvd" id="frm_dvd" class="checkbox" />
									<label for="frm_dvd">DVD authoring</label>
								</span>
								<span>
									<input type="checkbox" name="frm_voice" id="frm_voice" class="checkbox" />
									<label for="frm_voice">Voice-over</label>
								</span>
								<span>
									<input type="checkbox" name="frm_custom" id="frm_custom" class="checkbox" />
									<label for="frm_custom">Custom music</label>
								</span>
								<span>
									<input type="checkbox" name="frm_library" id="frm_library" class="checkbox" />
									<label for="frm_library">Library music</label>
								</span>
								<span>
									<input type="checkbox" name="frm_soundDes" id="frm_soundDes" class="checkbox" />
									<label for="frm_soundDes">Sound design</label>
								</span>
								</div>
							</div>
							<div class="h_list" id="equpment_div">
								<div class="label">Equipment: (check all that apply)</div>
								<div class="options">
									<span>
										<input type="checkbox" name="frm_hd" id="frm_hd" class="checkbox" />
										<label for="frm_hd">HD cameras</label>
									</span>
									<span>
										<input type="checkbox" name="frm_dofadaptors" id="frm_dofadaptors" class="checkbox" />
										<label for="frm_dofadaptors">Depth-of-field adaptors</label>
									</span>
									<span>
										<input type="checkbox" name="frm_audio" id="frm_audio" class="checkbox" />
										<label for="frm_audio">Audio equipment</label>
									</span>
									<span>
										<input type="checkbox" name="frm_jibs" id="frm_jibs" class="checkbox" />
										<label for="frm_jibs">Jibs, dollys</label>
									</span>
								</div>
							</div>
			            	<div class="button_div">
								<input type="submit" value="Submit" name="submit" id="frm_submit" class="button" />
								<span>* Required Information</span>
							</div>
						</fieldset>
			        </form>
			    <?
			        }
			    ?>
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>