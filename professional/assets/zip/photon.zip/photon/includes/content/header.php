<div id="header">
	<a href="index.php" id="logo"><img src="images/header_logo.png" alt="logo" /></a>
	<div class="information">
		<img src="images/header_info.jpg" alt="information" usemap="#informationMap" />
	</div><!-- .information -->
	<div class="navigation">
		<span class="contact"><a href="contact.php"><img src="images/header_contact.png" alt="contact" /></a></span>
		<span class="team"><a href="team.php"><img src="images/header_team.png" alt="team" /></a></span>
	</div><!-- .navigation -->
	<map name="informationMap" id="informationMap">
		<area shape="rect" coords="0,62,197,98" href="mailto:info@photoncreative.com" alt="info@photoncreative.com" />
	</map>
</div><!-- #header -->