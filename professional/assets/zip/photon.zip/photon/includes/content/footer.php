	<div id="footer">
		copyright &copy; 2009 Photon | All Rights Reserved
	</div><!-- #footer -->