<?php
    $page = $_GET['p'];
?>
<div id="content_navigation">
	<ul class="navigation">
		<li><a href="production.php"><img src="images/navigation_production.png" alt="production" /></a></li>
		<li><a href="post.php"><img src="images/navigation_post.png" alt="post-production" /></a></li>
		<li><a href="motion.php"><img src="images/navigation_motion.png" alt="motion" /></a></li>
		<li><a href="films.php"><img src="images/navigation_films.png" alt="films" /></a></li>
		<li><a href="quote.php"><img src="images/navigation_quote.png" alt="get quote" /></a></li>
	</ul><!-- #content_navigation -->
	<div id="content_blurb">
		<?php
	        $blurb = $_GET['b'];
			$arr = array(
				"home" => "We offer comprehensive high definition production services as well as editing, motion graphics and audio work; everything you need to tell your story in the most compelling and exciting way possible.",
				"production" => "With over two decades of production experience, the Photon team has the knowledge and expertise to put your ideas on the screen. We provide clear creative vision, thorough production planning, and smooth execution from start to finish.",
				"post" => "Editing, graphics, animation and sound... This is where your story really gets told. Let us apply our creative expertise and our serious aptitude for technology and make your show the best it can be.",
				"motion" => "Integrating the latest animation techniques, with a keen editorial eye, gives your show a sophistication and visual appeal that stands out in a crowd. Let us apply the finishing touches that deliver your message with maximum impact!",
				"films" => "Our work also extends into narrative features, documentaries, and short films. We have significant experience with independent cinema, and provide collaboration and services during both production and post. Here are some of the projects currently making the rounds in the festival circuit.",
				"quote" => "Photons dedicated team of media professionals takes the time to listen to both your requests and your aspirations.",
				"contact" => "",
				"team" => "We harness our creative vision, our technical know-how and our extensive resource network to make sure that every story reaches its full potential."
			);
			if($blurb){
	        	echo "<span>".$arr[$blurb]."</span>";
			}
	    ?>
	</div>
	<div id="content_current">
		<div class="title"><a href="demo09.php?movie=/media/Photon_showreel_2009.flv" rel="prettyPopin">FEATURED WORK</a></div><!-- .title -->
		<div class="play"><a href="demo09.php?movie=/media/Photon_showreel_2009.flv" rel="prettyPopin"><img src="images/play.png" alt="play" /></a></div><!-- .play -->
		<div class="work"><a href="demo09.php?movie=/media/Photon_showreel_2009.flv" rel="prettyPopin"><img src="images/sidebar_showreel.gif" alt="featured project" /></a></div><!-- .work -->
	</div><!-- #content_current -->
</div><!-- #content_navigation -->