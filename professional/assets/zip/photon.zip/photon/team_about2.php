<?php include("includes/global/header.php"); ?>
<div id="page_team_mcfarland" class="page_team">
<?php include("includes/content/header.php"); ?>
	<script>
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'team'; //set the blurb image path
			$_GET['p'] = 'header_team_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
			<img src="images/BM.png" alt="" width="150" height="103" border="3">
			<p><strong>Brandon McFarland</strong> - Editor/Designer<br>
			<a href="mailto:bmc@photoncreative.com">bmc@photoncreative.com</a></p>
			<p>Brandon is a Bay Area native and joined Photon in 2006.  He focuses his keen creative and technical skills on the post-production arena as a video editor and motion graphics designer. </p>
			<p>Starting his video career young, Brandon initially approached filmmaking as a way to document youth skate culture, but soon realized he had found his niche. His pre-med courses were sidetracked once he began to study filmmaking, leading him to the Academy of Art University where he earned his BFA in Motion Pictures and Television.  </p>
			<p>Brandon has worked on a number of feature length documentaries, and numerous short films, music videos, communications videos, and TV commercials. Brandon worked for Current Video prior to joining the Photon team and has had the opportunity to work with many high-profile clients such as Microsoft, Intel, Adobe, Gateway Computers, and Colgate-Palmolive. He enjoys the interactions and challenges presented by a busy, client-centric workload, and continues to pursue new creative heights while diligently addressing client needs. </p>
			<p>Outside of his work at Photon, Brandon enjoys rock climbing, biking and engaging in both scientific study and humanitarian causes.
			</p>
			<p><a href="team.php">back to team</a></p>
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>