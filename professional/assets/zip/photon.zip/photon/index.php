<?php include("includes/global/header.php"); ?>
<script type="text/javascript">
var psXMLFile = "home.xml";
</script>
<div id="page_homepage">
<?php include("includes/content/header.php"); ?>

    <div id="content">
			<?php
				$_GET = array(); // make an array for the GET call
				$_GET['b'] = 'home'; //set the image path
	            include("includes/content/subNav.php"); 
	        ?>
        <div id="main_content">
			<a href="demo09.php?movie=/media/Photon_showreel_2009.flv" class="video_play" rel="prettyFixed"><span>CLICK TO VIEW OUR CURRENT SHOWREEL</span></a><!-- .video_play -->
			<div class="slideshow"></div><!-- .slideshow -->
		</div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>