<?php include("includes/global/header.php"); ?>
<div id="page_contact">
<?php include("includes/content/header.php"); ?>
	<script>
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['p'] = 'header_contact_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
            
		    <strong>Photon</strong><br />
		    1136 Clement St.<br />
		    San Francisco, CA, 94118<br />
		    Office 415-751-0499<br />
		    Fax 415-751-0499<br />
		    <a href="mailto:info@photoncreative.com">info@photoncreative.com</a><br />
		    <p><strong>For directions click the map</strong></p>
		    <a href="contact_map.php" class="map"><img src="images/map.png" alt="map" border="0" /></a>
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>