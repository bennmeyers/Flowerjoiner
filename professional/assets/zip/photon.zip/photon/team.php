<?php include("includes/global/header.php"); ?>
<div id="page_team" class="page_team">
<?php include("includes/content/header.php"); ?>
	<script type="text/javascript">
	var psXMLFile = null;
	</script>

    <div id="content">
		<?php
			$_GET = array(); // make an array for the GET call
			$_GET['b'] = 'team'; //set the blurb image path
			$_GET['p'] = 'header_team_a'; //set the selected image path
	        include("includes/content/subNav.php"); 
    	?>
        <div id="main_content">
			<div class="members">
				<div class="member">
					<a href="team_about1.php">Brandon Butrick</a>
					<div>Producer and Owner</div>
				</div><!-- .member -->
				<div class="member">
					<a href="team_about2.php">Brandon McFarland</a>
					<div>Editor/Designer</div>
				</div><!-- .member -->
				<div class="member">
					<a href="team_about3.php">Rebekah Renne</a>
					<div>Associate Producer</div>
				</div><!-- .member -->
			</div><!-- .members -->
			<div class="slideshow">
			  <img src="images/main_team_1.jpg" alt="main image" />
			  <img src="images/main_team_2.jpg" alt="main image" />
			  <img src="images/main_team_3.jpg" alt="main image" />
			  <img src="images/main_team_4.jpg" alt="main image" />
			  <img src="images/main_team_5.jpg" alt="main image" />
			  <img src="images/main_team_6.jpg" alt="main image" />
			  <img src="images/main_team_7.jpg" alt="main image" />
			  <img src="images/main_team_8.jpg" alt="main image" />
			  <img src="images/main_team_9.jpg" alt="main image" />
			  <img src="images/main_team_10.jpg" alt="main image" />
			</div>
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div><!-- #page_homepage -->
<?php include("includes/global/footer.php"); ?>