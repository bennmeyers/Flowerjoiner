<?php include("includes/global/header.php"); ?>
<div id="resources">
<?php include("includes/content/header.php"); ?>

    <div id="content">
<?php include("includes/content/subNav.php"); ?>
        <div id="main_content">
<?php include("includes/content/promotion.php"); ?>
            <div class="main">
				<p>Get connected to amazing non-profit organizations that are making a difference in the world.</p>
				<a href="/pdf/WRKid-resources.pdf" target="_blank"><img src="/images/resource_pdf.gif" alt="download our resource guide" /></a>
			</div><!-- .main -->
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div>
<?php include("includes/global/footer.php"); ?>