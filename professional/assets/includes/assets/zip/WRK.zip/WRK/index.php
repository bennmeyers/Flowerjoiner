<?php include("includes/global/header.php"); ?>
<div id="homepage">
<?php include("includes/content/header.php"); ?>

    <div id="content">
<?php include("includes/content/subNav.php"); ?>
        <div id="main_content">
<?php include("includes/content/promotion.php"); ?>
            <div class="main">
				<p>World Repair Kids unleashes the superhero in every kid&mdash;the protectors, the fixers, the champions of good. Our mission is to spark a by-kids-for-kids movement by providing the inspiration and tools for social change, including connections to some of the most amazing non-profit organizations around the world. But it's not just about kids. Everyone has a role in World repair&mdash;parents, neighbors, schools, businesses. It's a community effort and a family affair. We believe that with the right tools and resources, anything is possible. <i>Together, we can change the world.</i></p>
            	<a href="products.php"><img src="/images/arrow_learn_more.gif" alt="learn more" /></a>
			</div><!-- .main -->
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div>
<?php include("includes/global/footer.php"); ?>