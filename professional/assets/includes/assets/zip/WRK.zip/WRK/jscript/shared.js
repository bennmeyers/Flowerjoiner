/*
development javascript
*/
$(document).ready(function(){
	$('#loop form').submit(function(event){
		event.preventDefault(); // prevent the form from activating
		var lsAction = $(this).attr("action"); // put the form action in a variable
		var lsMvariable = $('#m').val(); // put the M value in a variable
		var lsPvariable = $('#p').val(); // put the P value in a variable
		var lsEAvariable = $('#ea').val(); // put the EA value in a variable
		var lsLocation = $(this).attr("target"); // put the form target in a variable
		
		$('#form_submit').attr("href",'popin.html?a=' + lsAction + '&m=' + lsMvariable + '&p=' + lsPvariable + '&ea=' + lsEAvariable).click(); // put the variables in an anchor tag and click on the anchor !wrong way but works!
	});
	$("a[rel^='prettyPopin']").prettyPopin({opacity:0.3}); // set the opacity value
});