<?php include("includes/global/header.php"); ?>
<div id="loop">
<?php include("includes/content/header.php"); ?>

    <div id="content">
<?php include("includes/content/subNav.php"); ?>
        <div id="main_content">
<?php include("includes/content/promotion.php"); ?>
            <div class="main">
				<!-- BEGIN: MODIFIED Constant Contact Basic Opt-in Email List Form -->
				<form name="ccoptin" action="http://visitor.constantcontact.com/d.jsp" target="loop_signup" method="post" id="frm_loop">
					<input type="hidden" id="m" name="m" value="1102853718694" />
					<input type="hidden" id="p" name="p" value="oi" />
					<input type="text" id="ea" name="ea" value="" class="text" />
					<input type="submit" name="go" value="" class="submit" id="button" />
				</form>
				<!-- END: MODIFIED Constant Contact Basic Opt-in Email List Form -->
				<p>To learn more, please contact us at <a href="mailto:info@worldrepairkids.org">info@worldrepairkids.org</a></p>
				<a href="#" rel="prettyPopin" id="form_submit" style="display:none">popin</a>
			</div><!-- .main -->
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div>
<?php include("includes/global/footer.php"); ?>