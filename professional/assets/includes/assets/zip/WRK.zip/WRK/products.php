<?php include("includes/global/header.php"); ?>
<div id="products">
<?php include("includes/content/header.php"); ?>

    <div id="content">
		<?php include("includes/content/subNav.php"); ?>
        <div id="main_content">
<?php include("includes/content/promotion.php"); ?>
            <div class="main">
				<p>The World Repair Kit is a comprehensive activity kit packed with quick facts and hands-on activities that empower kids to make a difference every day. Includes 205-page guide book, activity passport, stamps, stickers and more. Recommended for ages 8-108! 100% of net proceeds go to The Serena &amp; Lily Foundation, funding youth initiatives around the world. $24.95</p>
				<a href="http://www.serenaandlily.com/Gift/Gift-WorldRepairKit" class="kit"><img src="/images/product_WRK.gif" alt="World Repair Kit" /></a>
			</div><!-- .main -->
        </div><!-- #main_content -->

    </div><!-- #content -->
<?php include("includes/content/footer.php"); ?>

</div>
<?php include("includes/global/footer.php"); ?>