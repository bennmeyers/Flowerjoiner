<div id="sub_navigation"><img src="/images/tabs_main.gif" alt="About Us | Products | Resource Guide | Stay in the Loop" usemap="#navigation_map" /></div><!-- #sub_navigation -->
<map name="navigation_map" id="navigation_map">
	<area shape="rect" coords="151,0,272,41" href="index.php" alt="About Us" />
	<area shape="rect" coords="272,0,391,41" href="products.php" alt="Products" />
	<area shape="rect" coords="391,0,561,41" href="resource.php" alt="Resource Guide" />
	<area shape="rect" coords="561,0,739,41" href="loop.php" alt="Stay in the Loop" />
</map><!-- #navigation_map -->