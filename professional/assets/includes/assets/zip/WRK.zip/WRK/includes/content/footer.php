<div id="footer">
	<a href="http://www.serenaandlily.com"><img src="/images/footer.gif" alt="serena and lily foundation" /></a>
</div><!-- #footer -->