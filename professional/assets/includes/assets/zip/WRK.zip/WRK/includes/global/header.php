<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>World Repair Kids</title>
	<script src="jscript/jquery.min.js?v=00" type="text/javascript"></script>
	<script src="jscript/jquery.prettyPopin.js?v=00" type="text/javascript"></script>
	<script src="jscript/shared.js?v=00" type="text/javascript"></script>
	<link href="css/reset.css?v=00" rel="stylesheet" type="text/css" media="all" />
	<link href="css/prettyPopin.css?v=00" rel="stylesheet" type="text/css" media="all" />
	<link href="css/main.css?v=00" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
	<div id="outerwrapper">
		<div id="innerwrapper">