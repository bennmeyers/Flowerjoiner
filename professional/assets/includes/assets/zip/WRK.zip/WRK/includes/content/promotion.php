<div class="promotion">
	<a href="products.php"><img src="images/promotion_WRK.gif" alt="World Repair Kit" /></a>
</div><!-- .promotion -->